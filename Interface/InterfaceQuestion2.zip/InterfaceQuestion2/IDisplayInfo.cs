using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterfaceQuestion2
{
    public interface IDisplayInfo
    {
        void Display();
    }
}