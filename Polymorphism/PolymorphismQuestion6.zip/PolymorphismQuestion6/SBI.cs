using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PolymorphismQuestion6
{
    public class SBI : Bank
    {
        public override double GetIntresetInfo()
        {
            return 7.5;
        }
    }
}