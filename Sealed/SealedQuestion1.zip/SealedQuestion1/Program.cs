﻿using System;
using System.Security.Cryptography.X509Certificates;
namespace SealedQuestion1;
class Program{
    public static void Main(string[] args)
    {


    }
}

