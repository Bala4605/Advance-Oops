﻿using System;
namespace SealedQuestion3;
class Program{
    public static void Main(string[] args)
    {
        
    }
}