using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedQuestion2
{
    public class DoctorInfo:PatientInfo
    {
        //cannot derive from sealed type 'PatientInfo'
        
    }
}