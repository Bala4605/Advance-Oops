﻿using System;
namespace SealedQuestion2;
class Program{
    public static void Main(string[] args)
    {
        
    }
}